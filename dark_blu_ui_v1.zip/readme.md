tried to make modern GT neon-blue UI

suitable for 1.12.2 GTCEu, AE2(+AE2UEL, +AE2stuff), JEI

contact: discord m009499